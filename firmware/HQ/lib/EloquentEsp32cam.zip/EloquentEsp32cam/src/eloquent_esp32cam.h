#ifndef ELOQUENT_ESP32CAM
#define ELOQUENT_ESP32CAM
#define MJPEG_HTTP_PORT 81
#define LOG_HELP(x) ESP_LOGD("HELP", x)

#include "./eloquent_esp32cam/camera/camera.h"

#endif