#pragma once

#include "./jpeg/JPEGDECWrapper.h"