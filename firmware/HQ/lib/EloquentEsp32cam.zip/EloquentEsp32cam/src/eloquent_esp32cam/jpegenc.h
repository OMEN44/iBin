#pragma once

#include "./jpeg/JPEGENCWrapper.h"